#{{{ Marathon
from default import *
    
def test():

    set_java_recorded_version("15.0.1")
    if window('Web Server:Stopped'):
        select('JTextField_10', '/Users/noric/Desktop/PagesA')
    close()

    pass
