#{{{ Marathon
from default import *
#}}} Marathon

def test():
    set_java_recorded_version("15.0.1")
    if window('Web Server:Stopped'):
        click('Start server_2')
    close()

    if window('Web Server:Running'):
        assert_p('Switch to maintenance mode', 'Text', 'false')
        assert_p('Switch to maintenance mode', 'Enabled', 'true')
    close()
 
        
    pass