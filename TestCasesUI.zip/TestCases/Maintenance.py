#{{{ Marathon
from default import *
#}}} Marathon

def test():

    set_java_recorded_version("15.0.1")
    if window('Web Server:Stopped'):
        click('Start server_2')
    close()

    if window('Web Server:Running'):
        select('Switch to maintenance mode', 'true')
    close()

    if window('Web Server:Maintenance'):
        assert_p('JTextField_0', 'Text', 'Server status:')
        assert_p('JTextField_0', 'Enabled', 'true')
        select('Switch to maintenance mode', 'true')
        assert_p('JTextField_2', 'Text', 'Server address:')
        assert_p('JTextField_2', 'Enabled', 'true')
        assert_p('JTextField_4', 'Text', 'Server listening port:')
        assert_p('JTextField_4', 'Enabled', 'true')
        assert_p('JTextField_1', 'Text', 'maintenance')
        assert_p('JTextField_1', 'Enabled', 'true')
        assert_p('JTextField_3', 'Text', '192.168.1.115')
        assert_p('JTextField_3', 'Enabled', 'true')
        assert_p('JTextField_5', 'Text', '8080')
        assert_p('JTextField_5', 'Enabled', 'true')
        assert_p('Start server', 'Text', 'Stop server')
        assert_p('Switch to maintenance mode', 'Text', 'true')
        assert_p('Switch to maintenance mode', 'Enabled', 'true')
        assert_p('JTextField_6', 'Text', 'Server listening on port:')
        assert_p('JTextField_6', 'Enabled', 'true')
        select('Switch to maintenance mode', 'true')
        assert_p('JTextField_9', 'Text', 'Web root directory:')
        assert_p('JTextField_9', 'Enabled', 'true')
        assert_p('JTextField_12', 'Text', 'Maintenance directory')
        assert_p('JTextField_12', 'Enabled', 'true')
        assert_p('JTextField_7', 'Text', '8080')
        assert_p('JTextField_7', 'Enabled', 'false')
        assert_p('JTextField_10', 'Text', '/Users/noric/Desktop/Pages')
        assert_p('JTextField_10', 'Enabled', 'true')
        assert_p('JTextField_13', 'Text', '/Users/noric/Desktop/Pages/maintenance')
        assert_p('JTextField_13', 'Enabled', 'false')
        assert_p('JTextField_8', 'Text', '')
        assert_p('JTextField_8', 'Enabled', 'true')
        assert_p('JTextField_11', 'Text', 'O')
        assert_p('JTextField_11', 'Enabled', 'true')
        assert_p('JTextField_14', 'Text', 'O')
        assert_p('JTextField_14', 'Enabled', 'true')
    close()


    pass